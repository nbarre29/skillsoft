1) https://www.youtube.com/watch?v=4iFHtnYXBtw (Writing and Reading XML with JAXB)
2) https://www.tutorialspoint.com/java/xml/javax_xml_bind_jaxbcontext_newinstance_classestobebound.htm